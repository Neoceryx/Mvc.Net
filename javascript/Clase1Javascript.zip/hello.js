
function muestraTipos(){

	var x = null;
	var nombre = "1";
	var numero = 1;
	
	console.log("Variable -nombre-: " + typeof nombre);
	console.log("Variable -numero-: " + typeof numero);
	console.log("Variable -x-: " + x);
	console.log("----------------------------------");
	console.log("Tipo de -x-: " + typeof x);
	console.log("Tipo de -y-: " + typeof y);
	console.log("Variable -y-: " + y);
	console.log("No voy a mostrar este log");
}

function muestraComparacionAbstracta(){
	
	var uno = 1;
	var otroUno = 1;
	var stringUno = "1";
	var cero = 0;
	var falsa = false;
	var nula = null;
	
	console.log("*********************Comparacion Abstracta*********************");
	console.log("Comparacion de -uno- y -otroUno-: " + comparacionAbstracta(uno, otroUno));
	console.log("Comparacion de -uno- y -stringUno-: " + comparacionAbstracta(uno, stringUno));
	console.log("Comparacion de -cero- y -falsa-: " + comparacionAbstracta(cero, falsa));
	console.log("Comparacion de -cero- y -nula-: " + comparacionAbstracta(cero, nula));
	console.log("Comparacion de -cero- y -undefined-: " + comparacionAbstracta(cero, undefined));
	console.log("Comparacion de -nula- y -undefined-: " + comparacionAbstracta(nula, undefined));
}

function muestraComparacionEstricta(){
	
	var uno = 1;
	var otroUno = 1;
	var stringUno = "1";
	
	console.log("*********************Comparacion Estricta*********************");
	console.log("Comparacion de -uno- y -otroUno-: " + comparacionEsctricta(uno, otroUno));
	console.log("Comparacion de -uno- y -stringUno-: " + comparacionEsctricta(uno, stringUno));
}

function muestraComparacionDesigualAbstracta(){
	
	var cero = 0;
	var uno = 1;
	var dos = 2;
	var stringUno = "1";
	var verdad = true;
	var falso = false;
	
	console.log("*********************Comparacion Desigual Abstracta*********************");
	console.log("Comparacion de -uno- y -dos-: " + comparacionDesigualAbstracta(uno, dos));
	console.log("Comparacion de -uno- y -stringUno-: " + comparacionDesigualAbstracta(uno, stringUno));
	console.log("Comparacion de -uno- y -verdad-: " + comparacionDesigualAbstracta(uno, verdad));
	console.log("Comparacion de -cero- y -falso-: " + comparacionDesigualAbstracta(cero, falso));
}

function muestraComparacionDesigualEstricta(){
	
	var tres = 3;
	var otroTres = 3;
	var stringTres = "3";
	
	console.log("*********************Comparacion Desigual Estricta*********************");
	console.log("Comparacion de -tres- y -otroTres-: " + comparacionDesigualEstricta(tres, otroTres));
	console.log("Comparacion de -tres- y -stringTres-: " + comparacionDesigualEstricta(tres, stringTres));
}

function muestraComparacionAdicional(){
	
	var hola = "Hola";
	var holaObjeto = new String("Hola");
	var holaObjeto2 = new String("Hola");
	
	console.log("*********************Comparacion Adicional*********************");
	console.log("Comparacion de -holaObjeto- y -holaObjeto2-: " + comparacionAbstracta(holaObjeto, holaObjeto2));
	console.log("Comparacion de -holaObjeto- y -holaObjeto2-: " + comparacionEsctricta(holaObjeto, holaObjeto2));
	console.log("Comparacion de -holaObjeto- y -hola-: " + comparacionAbstracta(holaObjeto, hola));
}

function comparacionAbstracta(var1, var2){
	return (var1 == var2);
}

function comparacionEsctricta(var1, var2){
	return (var1 === var2)
}

function comparacionDesigualAbstracta(var1, var2){
	return (var1 != var2);
}

function comparacionDesigualEstricta(var1, var2){
	return (var1 !== var2);
}
