info = function () {

    var init = function () {
		registerCustomHelper();
        initData();
		initEvents();
    };
	
	function initData(){
		
		var userData = [
			{name: "Charlie", age: 33, color: "red"},
			{name: "Eduardo", age: 29, color: "blue"},
			{name: "Karla", age: 31, color: "yellow"},
			{name: "Aldo", age: 26, color: "purple"}
		];
		
		// Obten el HTML del template
		var userTemplate = $("#user-template").html();
		
		// Compila el template
		var compiledTemplate = Handlebars.compile(userTemplate);
		
		$("#user-list").append(compiledTemplate(userData));
	}
	
	function registerCustomHelper(){
		
		Handlebars.registerHelper("evaluateAgeHelper", evaluateAge);
		
	}
	
	function initEvents(){
		
		$("li").on("click", function(){
			
			var myColor = $(this).data("color");
			console.log(myColor);
		});
		
		$("li a").on("click", function(event){
			
			event.stopPropagation();
			
			var listItem = $(this).parent();
			
			$(listItem).data("color", "green");
			
		});
	}
	
	function evaluateAge(age){
		
		if(age < 30)
		{
			return "Joven";
		}
		else if(age > 30)
		{
			return "Experimentado";
		}		
	}
	
    return {
        initialize: init
    }

}();