﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace GenericWebsite.Controllers
{
    public class InfoController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Info()
        {
            return View();
        }

        [HttpGet]
        public ActionResult GetData()
        {
            var someResultObject = new { Id = "8883", Name = "Charlie" };
            return Json(someResultObject, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult UpdateData(string name)
        {
            var newName = string.Format("Mr. {0}", name);
            var someResultObject = new { Success = true, Name = newName};

            return Json(someResultObject, JsonRequestBehavior.AllowGet);            
        }
    }
}
