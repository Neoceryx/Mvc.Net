﻿moduloAjax = function () {

    var init = function () {
        
        $("#GetContentBtn").on("click", function () {
            $.ajax(
			{
			    url: "http://localhost:51901/info/info",
			    success: function (result) {
			        console.log(result);
			        $(".container").html(result);
			    }
			}
			);
        });

        $("#GetDataBtn").on("click", function () {
            $.ajax(
			{
			    url: "http://localhost:51901/info/getdata",
			    success: function (result) {
			        console.log(result);
			        $("#dataId").text(result.Id);
			        $("#dataName").html(result.Name);
			    }
			}
			);
        });

        $("#UpdateDataBtn").on("click", function () {

            var nameText = $("#nameTxt").val();
            var formData = { name: nameText };

            $.ajax(
			{
			    url: "http://localhost:51901/info/UpdateData",
			    type: "POST",
			    data: formData,
			    success: function (result) {
			        console.log(result);
			        $("#newName").text(result.Name);
			    }
			}
			);
        });

    };

   

    return {
        initialize: init
    }

}();