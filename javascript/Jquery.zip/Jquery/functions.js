functions = function () {

    var init = function () {
        initChange();
		initAnimations();
		initAirlines();
		initGrep();		
    };
	
	function initChange(){
		
		$(".target").change(function(){
			console.log($(this).val());
		});
		
	}

	function initAnimations(){
		
		$("#start").on("click", function(){
			
			animateBox();
			
		});
		
		$("#reset").on("click", function(){
			
			$("#box").queue('fx',[]);
			
		});
		
		$("#add").on("click", function(){
			
			$("#box").queue(
				function(){
					$(this).animate({ width: '300px' }, 2000);
					$(this).dequeue();
				}
			);
			
		});
		
	}
	
	function animateBox(){
		$("#box").slideUp(2000)
			.slideDown(2000)
			.show(2000,animateBox);
	}

	function initAirlines(){
		
		$("#btnAddAirline").on("click", addAirline);
		
		$("#airlines").on("click", function(){
			console.log("Click en container airlines");
		});
		
		bindAirlineEvent();
	}
	
	function bindAirlineEvent(){
		
		var allListItems = $("#list > li");
				
		// allListItems.each(function(){
			// console.log($(this));
			// $(this).on("click", function(){
				
				// alert("La aerolinea es: " + $(this).text());
				
			// });
			
		// });
		
		// allListItems.on("click", function(){
			
			// alert("la aerolinea es: " + $(this).text());
			
		// });
		
		// $("#list").on("click", "li", function(event){
			
			// event.stopPropagation();
			// alert("la aerolinea es: " + $(this).text());
			
		// });
		
	}
	
	function addAirline(){
		var ul = $("#airlines ul");
		var airlineText = $("#txtAirline");
		
		ul.append("<li>" + airlineText.val() + "</li>");
		airlineText.val("");
	}
	
	function initGrep(){
		$("#btnFiltraGrep").on("click", filtraConGrep);
	}
	
	function filtraConGrep(){
		
		var textFilter = $("#txtFilter");
		var toFilter = $("#toFilter");
		var numberArray = toFilter.text().split(",");
		
		var filteredNumbers = $.grep(numberArray, function(num, index){
			return num > textFilter.val();
		});
		
		toFilter.html(filteredNumbers.join(","));
	}
	
    return {
        initialize: init
    }

}();