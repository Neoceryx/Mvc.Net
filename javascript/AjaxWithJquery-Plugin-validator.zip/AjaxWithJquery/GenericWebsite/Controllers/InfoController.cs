﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace GenericWebsite.Controllers
{
    public class InfoController : Controller
    {
        public class UserViewModel {

            public int id { get; set; }

            public string FirstName { get; set; }

            public string LastName { get; set; }

            public string Username { get; set; }

            public string Email { get; set; }

            public int Age { get; set; }

            public DateTime DateOfBirth { get; set; }

            public int UserTypeSelected { get; set; }

            public UserType UserType { get; set; }
        }

        public enum UserType
        {
            Normal = 1,
            Advanced = 2
        }

        public ActionResult Index()
        {
            return View();
        }
         
        public ActionResult Info()
        {
            return View();
        }

        [HttpGet]
        public ActionResult GetData()
        {
            var someResultObject = new { Id = "8883", Name = "Charlie" };
            return Json(someResultObject, JsonRequestBehavior.AllowGet);
        }

        [HttpGet]
        public ActionResult UserForm() { 
            return View(new UserViewModel());
        }

        [HttpPost]
        public ActionResult UserForm(UserViewModel viewModel) {
            return View(new UserViewModel());
        }

        [HttpPost]
        public ActionResult UpdateData(string name)
        {
            var newName = string.Format("Mr. {0}", name);
            var someResultObject = new { Success = true, Name = newName};

            return Json(someResultObject, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult ValidateUsername(string username)
        {
            var result = true;

            if (username == "DonaldTrump") {
                result = false;
            }

            return Json(result, JsonRequestBehavior.AllowGet);            
        }
    }
}
