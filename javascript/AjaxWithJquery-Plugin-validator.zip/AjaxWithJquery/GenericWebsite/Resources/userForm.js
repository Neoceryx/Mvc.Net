﻿userForm = function () {

    var init = function () {
        InitializeDatepicker();
        InitValidations();
        AddDefaultValueToDropdownlist();
    };

    function InitializeDatepicker() {
        // Initialize datepicker
        $("#DateOfBirth").datepicker();
    }

    function AddDefaultValueToDropdownlist() {
        // Add select at the start of the dropdown
        $('#UserType').children("option").eq(0).before($("<option selected></option>").val("").text("Select"));
    }

    function InitValidations() {

        $("#SaveForm").validate(

            {
                rules: {

                    FirstName: {
                        required: true
                    },
                    LastName: {
                        required: true
                    },
                    Age: {
                        required: true,
                        range: [15,99]
                    },
                    Email: {
                        required: true,
                        email: true
                    },
                    UserType: {
                        required: true
                    },
                    Username: {
                        required: true,
                        remote: {
                            url: "ValidateUsername",
                            type: "post",
                            data: {
                                username: function(){
                                    return $("#Username").val();
                                }
                            }
                        }
                    }
                }
            }

        );

    }

    return {
        initialize: init
    }

}();