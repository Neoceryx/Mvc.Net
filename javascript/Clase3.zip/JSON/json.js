var userDataJSONString = '{"nombre" : "Charlie","edad" : "33","sitioWeb" : "www.arkusnexus.com.mx"}';

var userDataObject = JSON.parse(userDataJSONString);

console.log(userDataObject.nombre);

var userDataString = JSON.stringify(userDataObject);

console.log(userDataString);

