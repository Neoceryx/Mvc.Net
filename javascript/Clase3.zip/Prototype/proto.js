
// Este objeto funciona como un factory
// Crea un nuevo objeto que usa el objeto especificado como su prototype
function object(o){

	function F(){
	};
	
	F.prototype = o;
	
	return new F();
}

var padre = { nombre: "Charles SR.", apellido: "Brown" };
var hijo = object(padre);

hijo.nombre = "Charlie";

console.log(hijo.nombre + " " + hijo.apellido);