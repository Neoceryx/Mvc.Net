var objeto = {};
var nuevaPersona = null;

function populaObjeto(){
	
	var nombreIngresado = document.getElementById("tbxNombre");
	
	document.getElementById("lblNotifica").style.display = "inline";
	document.getElementById("btnMuestraNombre").style.display = "inline";
		
	objeto = {
		nombre: nombreIngresado.value,
		muestraNombre: function(){
			
			var labelNotifica = document.getElementById("lblNombreDisplay");
			labelNotifica.style.display = "inline";
			labelNotifica.innerHTML = "El nombre que ingresaste fue: " + this.nombre;
		}
	}
	
}

// ***********************************************************************************

function creaPersona(){
	
	var nombreIngresado = document.getElementById("tbxNombre");
	nuevaPersona = new Persona(nombreIngresado.value);
	
	document.getElementById("lblNotifica").style.display = "inline";
	document.getElementById("btnMuestraNombrePersona").style.display = "inline";
}

var Persona = function (name){
	
	this.nombre = name;
	this.muestraNombre = function(){
		var labelNotifica = document.getElementById("lblNombreDisplay");
		labelNotifica.style.display = "inline";
		labelNotifica.innerHTML = "El nombre que ingresaste fue: " + this.nombre;
	};
	
};