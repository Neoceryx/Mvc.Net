function modificaHTMLAntipatron(){
	
	for(var i=0; i < 10000 ; i++){
		document.getElementById("resultado").innerHTML += i + ", ";
	}
}

function modificaHTML(){
	
	var i, contenido = "";
	
	for(i=0; i < 10000 ; i++){
		contenido += i + ", ";
	}	
	
	document.getElementById("resultado").innerHTML = contenido;
}

function muestraEstiloAntipatron(){
	
	var padding = document.getElementById("resultado").style.padding,
		margin = document.getElementById("resultado").style.margin;
		
	console.log("Padding: " + padding + " | Margin: " + margin);
	
}

function muestraEstilo(){
	
	var style = document.getElementById("resultado").style,
		padding = style.padding,
		margin = style.margin;
	
	console.log("Padding: " + padding + " | Margin: " + margin);
}

function muestraSelectores(){
	
	var main = document.querySelector("#main");
	console.log("main: " + main);
	console.log("-------------");
	
	var insideMainSpan = main.querySelector("span");
	console.log("Spans inside main: " + insideMainSpan);
	console.log("-------------");
	
	var insideMainOnlyFirstDiv = main.querySelector("div");
	var insideMainAllDivs = main.querySelectorAll("div");
	console.log("First Div inside main: " + insideMainOnlyFirstDiv.innerHTML);
	console.log("All divs inside main: " + insideMainAllDivs);
	
	for(var i=0 ; i < insideMainAllDivs.length ; i++ ){
		console.log("Div in main: " + insideMainAllDivs[i].innerHTML);
	}
	console.log("-------------");
	
	var spanInsideRockyDiv = main.querySelector(".rocky span");
	console.log("Span inside rocky div: " + spanInsideRockyDiv.innerHTML);
	console.log("-------------");
	
	var inputTextInMain = main.querySelector("#name");	
	console.log("Input text: " + inputTextInMain.value);
	
}

function agregaAlDOM(){
	// Antipatron
	
	var p, t;
	
	p = document.createElement('p');
	t = document.createTextNode('Primer parrafo');
	p.appendChild(t);
	document.body.appendChild(p);
	
	p = document.createElement('p');
	t = document.createTextNode('Segundo parrafo');
	p.appendChild(t);
	document.body.appendChild(p);
}

function agregaAlDOMConFragment(){
	
	var p, t, frag;
	
	frag = document.createDocumentFragment();
	
	p = document.createElement('p');
	t = document.createTextNode('Primer parrafo');
	p.appendChild(t);
	frag.appendChild(p);
	
	p = document.createElement('p');
	t = document.createTextNode('Segundo parrafo');
	p.appendChild(t);
	frag.appendChild(p);
	
	document.body.appendChild(frag);	
}

function addEvent(){
	
	var boton = document.getElementById("clickMeButton");
	
	boton.onclick = function (){
		alert("Click!");
	};
}

function addEventAlternative(){
	var boton = document.getElementById("clickMeButton");
	
	boton.addEventListener('click', genericFunction);
}

function genericFunction(){
	alert("Click! from alternative method");
}

function otherHandler(e){
	
	var src = e.target || e.srcElement;
	
	if(src.nodeName.toLowerCase() !== "button"){
		console.log("Diste click dentro del div pero no dentro de un boton");
		return;
	}

	switch(src.innerHTML){
		
		case "Button One":
			console.log("Click en boton 1");
		break;
		
		case "Button Two":
			console.log("Click en boton 2");
		break;
		
		case "Button Three":
			console.log("Click en boton 3");
		break;
	}
	
}

(function() {
  
  var divWrap = document.getElementById("button-wrap");
  
  divWrap.addEventListener("click", otherHandler)
  
})();